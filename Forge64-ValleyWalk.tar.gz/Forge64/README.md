# Forge64 — Valley Walk (Phase 1)

A small **free** Unity project you can open and play. Walk a foggy sakura river valley in an **N64-era adventure** style (inspired by classic outdoor Zelda adventure games — all original art/geometry, no ROM assets, no Nintendo IP claimed).

No paid services. No Asset Store packages. Works offline once Unity is installed.

---

## What this is

1. Open the project in Unity Hub (Personal / free).
2. Open the scene **Forge64Valley**.
3. Press **Play**.
4. The valley **auto-builds** so you can walk right away. Use the on-screen UI to tweak a prompt, stub-generate concept art, or rebuild the map.

You explore a enclosed outdoor valley: river path, grassy banks, cliff walls, pink blossom trees, a distant snow mountain, soft fog, and low internal resolution (N64 look).

---

## Install Unity (free)

1. Download **Unity Hub** (free): https://unity.com/download  
2. In Hub → **Installs** → install **Unity 6** (6000.x) with the **Windows/Mac/Linux Build Support** modules you need.  
   - Prefer the **Universal Render Pipeline (URP)** / 3D URP modules if the installer offers them.  
3. **Also OK:** Unity **2022.3 LTS** with URP (if Unity 6 is unavailable). On first open Unity may adjust package versions — accept and let it finish.

Use **Unity Personal** (free) — you do not need Pro or Cloud.

---

## Open this project

1. Unity Hub → **Projects** → **Open** → choose this folder:  
   `Forge64` (the folder that contains `Assets`, `Packages`, `ProjectSettings`).
2. Wait for the first import (can take several minutes). Allow package downloads for URP if prompted.
3. If Unity asks about a **Render Pipeline** / URP asset, accept defaults or create a basic URP pipeline asset (Edit → Project Settings → Graphics).
4. In the **Project** window, go to `Assets/Scenes/` and double-click **Forge64Valley**.
5. Press the **Play** button at the top of the Editor.

**Backup safety:** Even if the scene is empty or a script reference is missing, a runtime bootstrap still starts the UI and builds the valley when you press Play.

---

## How to use the UI (no coding)

| Control | What it does |
|--------|----------------|
| **Prompt** field | Type a valley idea (stored for later AI art). |
| **Generate Concept** | Stub only — keeps the default sakura concept image. (Flux / API not wired; offline demo.) |
| **Build Map** | Rebuilds the walkable valley from the concept art. |
| **Save / Load** | Saves prompt + player position to a local file on your computer. |

**On-screen concept preview** (top-right) shows `default_valley.png`.

---

## Controls (adventure feel)

| Key | Action |
|-----|--------|
| **W / S** | Walk forward / back (tank-style, relative to facing) |
| **A / D** | Turn left / right |
| **Shift** | Run (still modest adventure pace) |
| **Space** | Small jump |
| **Q** or **Left Ctrl** | Recenter camera behind you (L-target-ish) |
| **Esc** | Toggle free mouse cursor (for UI) |
| Walk into **green tokens** | Collect sparkle tokens |

Third-person camera follows softly behind your character.

---

## Where files live

```
Forge64/
  README.md                 ← you are here
  .gitignore
  Assets/
    Scenes/Forge64Valley.unity
    Scripts/                ← all gameplay C#
    StreamingAssets/Concept/default_valley.png   ← default concept art
    Resources/Concept/default_valley.png         ← same image, Resources fallback
  Packages/manifest.json    ← includes URP
  ProjectSettings/          ← Unity 6–aimed project settings
```

Saves go to Unity’s **persistent data path** (a folder on your PC), not inside the project.

---

## What’s stubbed (Flux)

**Generate Concept** does **not** call the internet. It loads the bundled sakura valley image and remembers your prompt.

Later, a developer can plug image generation into `ConceptService.GenerateConceptStub` (see comments in that script) — e.g. Flux — then save a PNG under `StreamingAssets/Concept/` and reload. Phase 1 stays fully offline.

---

## Look & feel notes

- Soft unlit materials, limited palette, billboard blossom canopies  
- Heavy distance fog + ~320×240 (or 640×480) upscale  
- River path with playable banks, cliff enclosure, landmark mountain  
- Tank-style movement + third-person follow camera  

---

## Troubleshooting

- **Pink materials:** URP shaders not ready yet — wait for import, or set Graphics to URP. Unlit fallbacks should still show colors.  
- **Empty scene on Play:** Check the Console; bootstrap should still spawn. Use **File → Open Scene → Assets/Scenes/Forge64Valley**.  
- **Can’t move:** Click the Game view, press Esc if the cursor is stuck on UI, then use WASD.  
- **Script errors on older Unity:** Use 2022.3+ LTS or Unity 6; avoid very old editors.

---

## License / credit

Original project code and generated geometry for Forge64 Phase 1.  
Concept image is the project’s bundled reference art.  
Inspired by N64-era Zelda adventure games — not affiliated with Nintendo.
