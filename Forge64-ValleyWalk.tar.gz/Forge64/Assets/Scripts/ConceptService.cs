using System.IO;
using UnityEngine;

/// <summary>
/// Loads the default valley concept art for Phase 1.
/// STUB: Later, plug Flux (or similar) image generation here — call an API with the
/// prompt string, download the PNG into StreamingAssets/Concept/, then reload.
/// No network calls in this demo.
/// </summary>
public class ConceptService : MonoBehaviour
{
    public const string StreamingRelativePath = "Concept/default_valley.png";
    public const string ResourcesPath = "Concept/default_valley";

    [SerializeField] Texture2D currentConcept;
    public Texture2D CurrentConcept => currentConcept;

    public string LastPrompt { get; private set; } = "sakura river valley, snow mountain, N64 Zelda look";

    /// <summary>
    /// Load default concept from StreamingAssets, then Resources as fallback.
    /// </summary>
    public Texture2D LoadDefaultConcept()
    {
        // Prefer StreamingAssets so non-devs can drop a new PNG without reimport.
        string path = Path.Combine(Application.streamingAssetsPath, StreamingRelativePath);
        if (File.Exists(path))
        {
            byte[] bytes = File.ReadAllBytes(path);
            var tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            if (tex.LoadImage(bytes))
            {
                tex.name = "default_valley_streaming";
                currentConcept = tex;
                return currentConcept;
            }
        }

        var fromResources = Resources.Load<Texture2D>(ResourcesPath);
        if (fromResources != null)
        {
            currentConcept = fromResources;
            return currentConcept;
        }

        // Last resort: solid procedural tint so Build Map still works.
        currentConcept = CreateFallbackTexture(64, 64);
        return currentConcept;
    }

    /// <summary>
    /// Generate Concept (stub): keeps current default art and stores the prompt.
    /// FLUX HOOK: replace body with async image generation using LastPrompt.
    /// </summary>
    public Texture2D GenerateConceptStub(string prompt)
    {
        LastPrompt = string.IsNullOrWhiteSpace(prompt) ? LastPrompt : prompt.Trim();
        Debug.Log($"[ConceptService] Generate Concept stub — prompt stored: \"{LastPrompt}\". " +
                  "Flux/API not wired; showing default_valley.png. " +
                  "Plug-in point: ConceptService.GenerateConceptStub.");
        if (currentConcept == null)
            LoadDefaultConcept();
        return currentConcept;
    }

    static Texture2D CreateFallbackTexture(int w, int h)
    {
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        for (int y = 0; y < h; y++)
        {
            for (int x = 0; x < w; x++)
            {
                float nx = x / (float)(w - 1);
                float ny = y / (float)(h - 1);
                // Soft green valley, blue river band, pink accents, white peaks.
                bool river = Mathf.Abs(nx - 0.5f) < 0.08f;
                bool peak = ny > 0.75f;
                bool blossom = !river && ny > 0.35f && ny < 0.65f && ((x + y) % 7 == 0);
                Color c;
                if (peak) c = Color.Lerp(new Color(0.55f, 0.65f, 0.75f), Color.white, (ny - 0.75f) / 0.25f);
                else if (river) c = new Color(0.35f, 0.55f, 0.85f);
                else if (blossom) c = new Color(1f, 0.7f, 0.85f);
                else c = Color.Lerp(new Color(0.25f, 0.45f, 0.2f), new Color(0.45f, 0.6f, 0.3f), ny);
                tex.SetPixel(x, y, c);
            }
        }
        tex.Apply();
        tex.name = "fallback_valley";
        return tex;
    }
}
