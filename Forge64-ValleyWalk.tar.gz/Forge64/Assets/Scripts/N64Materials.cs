using UnityEngine;

/// <summary>
/// Unlit / vertex-color-leaning materials — soft, limited palette, no PBR shine.
/// </summary>
public static class N64Materials
{
    static Shader UnlitColorShader()
    {
        // Prefer URP Unlit, then Built-in Unlit, then Sprites, then Standard as last resort.
        return Shader.Find("Universal Render Pipeline/Unlit")
            ?? Shader.Find("Unlit/Color")
            ?? Shader.Find("Sprites/Default")
            ?? Shader.Find("Standard");
    }

    static Shader UnlitTextureShader()
    {
        return Shader.Find("Universal Render Pipeline/Unlit")
            ?? Shader.Find("Unlit/Texture")
            ?? Shader.Find("Unlit/Transparent")
            ?? Shader.Find("Sprites/Default")
            ?? Shader.Find("Standard");
    }

    public static Material ColorMat(Color c, bool transparent = false)
    {
        var sh = UnlitColorShader();
        var m = new Material(sh);
        ApplyColor(m, c, transparent);
        m.name = "N64Color";
        return m;
    }

    public static Material TextureMat(Texture tex, Color tint, bool transparent = false)
    {
        var sh = UnlitTextureShader();
        var m = new Material(sh);
        if (tex != null)
        {
            if (m.HasProperty("_BaseMap")) m.SetTexture("_BaseMap", tex);
            if (m.HasProperty("_MainTex")) m.SetTexture("_MainTex", tex);
        }
        ApplyColor(m, tint, transparent);
        m.name = "N64Tex";
        return m;
    }

    static void ApplyColor(Material m, Color c, bool transparent)
    {
        if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
        if (m.HasProperty("_Color")) m.SetColor("_Color", c);
        if (transparent)
        {
            // Best-effort alpha for URP/Built-in unlit
            if (m.HasProperty("_Surface")) m.SetFloat("_Surface", 1f);
            m.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            m.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            m.SetInt("_ZWrite", 0);
            m.DisableKeyword("_ALPHATEST_ON");
            m.EnableKeyword("_ALPHABLEND_ON");
            m.renderQueue = 3000;
        }
    }

    public static Texture2D SoftTintTex(Color a, Color b, int size = 32)
    {
        var t = new Texture2D(size, size, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Bilinear;
        t.wrapMode = TextureWrapMode.Repeat;
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float n = Mathf.PerlinNoise(x * 0.18f, y * 0.18f);
            t.SetPixel(x, y, Color.Lerp(a, b, n));
        }
        t.Apply();
        return t;
    }

    public static Texture2D SoftCircle(Color fill, int size = 64)
    {
        var t = new Texture2D(size, size, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Bilinear;
        float r = size * 0.48f;
        Vector2 c = new Vector2(size * 0.5f, size * 0.5f);
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float d = Vector2.Distance(new Vector2(x, y), c);
            float a = Mathf.Clamp01(1f - (d - (r - 2f)) / 3f);
            if (d > r) a = 0f;
            Color col = fill;
            col.a = a * fill.a;
            t.SetPixel(x, y, col);
        }
        t.Apply();
        return t;
    }
}
