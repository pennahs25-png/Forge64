using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// N64 presentation: render at ~320x240 (or 640x480), upscale with soft bilinear,
/// heavy field fog. Works with Built-in and URP by blitting through a UI RawImage
/// (URP does not reliably fire OnPostRender blits).
/// </summary>
[DisallowMultipleComponent]
public class N64Look : MonoBehaviour
{
    public enum ResMode { Res320x240 = 0, Res640x480 = 1 }

    [Header("Internal resolution")]
    public ResMode resolution = ResMode.Res320x240;
    public FilterMode upscaleFilter = FilterMode.Bilinear;

    [Header("Heavy distance fog")]
    public bool enableFog = true;
    public Color fogColor = new Color(0.62f, 0.72f, 0.88f, 1f);
    public float fogDensity = 0.028f;
    public float cameraFarClip = 95f;

    Camera cam;
    RenderTexture rt;
    Canvas blitCanvas;
    RawImage blitImage;

    void Awake()
    {
        cam = GetComponent<Camera>();
        if (cam == null)
            cam = gameObject.AddComponent<Camera>();
        ApplyFogAndSky();
        SetupRtAndBlit();
    }

    void OnDestroy()
    {
        if (cam != null) cam.targetTexture = null;
        if (rt != null)
        {
            rt.Release();
            Destroy(rt);
        }
        if (blitCanvas != null)
            Destroy(blitCanvas.gameObject);
    }

    public void ApplyFogAndSky()
    {
        if (enableFog)
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = fogColor;
            RenderSettings.fogDensity = fogDensity;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.55f, 0.58f, 0.62f);
        }
        else
            RenderSettings.fog = false;

        if (cam != null)
        {
            cam.backgroundColor = fogColor;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.farClipPlane = cameraFarClip;
            cam.nearClipPlane = 0.1f;
            cam.fieldOfView = 48f;
            cam.allowHDR = false;
            cam.allowMSAA = false;
        }
    }

    void SetupRtAndBlit()
    {
        if (cam != null) cam.targetTexture = null;
        if (rt != null)
        {
            rt.Release();
            Destroy(rt);
            rt = null;
        }

        int tw = resolution == ResMode.Res640x480 ? 640 : 320;
        int th = resolution == ResMode.Res640x480 ? 480 : 240;

        try
        {
            rt = new RenderTexture(tw, th, 16, RenderTextureFormat.ARGB32);
            rt.filterMode = upscaleFilter;
            rt.wrapMode = TextureWrapMode.Clamp;
            rt.antiAliasing = 1;
            rt.Create();
            cam.targetTexture = rt;
            EnsureBlitUi();
            blitImage.texture = rt;
        }
        catch (System.Exception e)
        {
            Debug.LogWarning("[N64Look] RT failed, fog-only: " + e.Message);
            if (cam != null) cam.targetTexture = null;
        }
    }

    void EnsureBlitUi()
    {
        if (blitCanvas != null) return;

        var go = new GameObject("N64BlitCanvas");
        DontDestroyOnLoad(go);
        blitCanvas = go.AddComponent<Canvas>();
        blitCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        blitCanvas.sortingOrder = -100; // behind HUD
        go.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;

        var imgGo = new GameObject("N64Frame");
        imgGo.transform.SetParent(go.transform, false);
        blitImage = imgGo.AddComponent<RawImage>();
        blitImage.color = Color.white;
        var rtRect = imgGo.GetComponent<RectTransform>();
        rtRect.anchorMin = Vector2.zero;
        rtRect.anchorMax = Vector2.one;
        rtRect.offsetMin = Vector2.zero;
        rtRect.offsetMax = Vector2.zero;
    }

    public void Refresh()
    {
        ApplyFogAndSky();
        SetupRtAndBlit();
    }
}
