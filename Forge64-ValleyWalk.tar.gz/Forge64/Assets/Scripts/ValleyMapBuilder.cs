using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Builds a walkable sakura river valley with OoT/MM outdoor-level readability:
/// clear river path, playable banks, cliff enclosure, landmark mountain,
/// billboard blossom canopies, placed props, soft fog lighting.
/// Uses concept texture luminance/colors as height hints when available.
/// </summary>
public class ValleyMapBuilder : MonoBehaviour
{
    [Header("Valley size")]
    public float worldSize = 96f;
    public int meshResolution = 64;
    public float maxHeight = 14f;

    Transform root;
    Texture2D concept;
    readonly List<GameObject> spawned = new List<GameObject>();

    public Transform ValleyRoot => root;
    public Vector3 RecommendedSpawn { get; private set; } = new Vector3(0f, 3f, -28f);

    public void Build(Texture2D conceptTex)
    {
        Clear();
        concept = conceptTex;
        root = new GameObject("ValleyRoot").transform;
        root.SetParent(transform, false);
        spawned.Add(root.gameObject);

        BuildTerrainMesh();
        BuildRiver();
        BuildCliffBounds();
        BuildDistantMountain();
        BuildSkyDome();
        PlaceSakuraTrees();
        PlaceProps();
        PlaceCollectibles();
        SetupLighting();

        RecommendedSpawn = SampleSpawnOnBank();
        Debug.Log("[ValleyMapBuilder] Sakura valley built.");
    }

    public void Clear()
    {
        for (int i = spawned.Count - 1; i >= 0; i--)
        {
            if (spawned[i] != null)
                Destroy(spawned[i]);
        }
        spawned.Clear();
        root = null;
    }

    // ---------- Terrain ----------
    void BuildTerrainMesh()
    {
        int res = meshResolution;
        float size = worldSize;
        var go = new GameObject("Terrain");
        go.transform.SetParent(root, false);
        spawned.Add(go);

        var mesh = new Mesh { name = "ValleyTerrain" };
        var verts = new Vector3[(res + 1) * (res + 1)];
        var cols = new Color[(res + 1) * (res + 1)];
        var uvs = new Vector2[(res + 1) * (res + 1)];
        var tris = new int[res * res * 6];

        for (int z = 0; z <= res; z++)
        {
            for (int x = 0; x <= res; x++)
            {
                float nx = x / (float)res;
                float nz = z / (float)res;
                float wx = (nx - 0.5f) * size;
                float wz = (nz - 0.5f) * size;
                float h = SampleHeight(nx, nz, wx, wz);
                int i = z * (res + 1) + x;
                verts[i] = new Vector3(wx, h, wz);
                uvs[i] = new Vector2(nx, nz);
                cols[i] = GroundColor(nx, nz, h, wx);
            }
        }

        int t = 0;
        for (int z = 0; z < res; z++)
        {
            for (int x = 0; x < res; x++)
            {
                int i = z * (res + 1) + x;
                tris[t++] = i;
                tris[t++] = i + res + 1;
                tris[t++] = i + 1;
                tris[t++] = i + 1;
                tris[t++] = i + res + 1;
                tris[t++] = i + res + 2;
            }
        }

        mesh.vertices = verts;
        mesh.colors = cols;
        mesh.uv = uvs;
        mesh.triangles = tris;
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        var mf = go.AddComponent<MeshFilter>();
        mf.sharedMesh = mesh;
        var mr = go.AddComponent<MeshRenderer>();
        // Soft green grass texture, unlit
        var grassTex = N64Materials.SoftTintTex(
            new Color(0.28f, 0.48f, 0.22f),
            new Color(0.42f, 0.62f, 0.30f), 48);
        mr.sharedMaterial = N64Materials.TextureMat(grassTex, Color.white);

        var col = go.AddComponent<MeshCollider>();
        col.sharedMesh = mesh;
    }

    float SampleHeight(float nx, float nz, float wx, float wz)
    {
        // River trench along Z through center X — clear adventure path
        float river = Mathf.Abs(wx);
        float riverMask = Mathf.SmoothStep(7.5f, 3.5f, river); // 1 near center
        float bank = Mathf.SmoothStep(3.5f, 9f, river);

        // Concept luminance as gentle height hint
        float hint = 0.35f;
        if (concept != null)
        {
            Color c = concept.GetPixelBilinear(Mathf.Clamp01(nx), Mathf.Clamp01(nz));
            hint = c.grayscale;
        }

        float hills = Mathf.PerlinNoise(nx * 3.2f + 2.1f, nz * 3.2f + 0.7f);
        float ridge = Mathf.PerlinNoise(nx * 1.1f, nz * 1.1f);

        // Playable banks ~1.2–2.2, river bed lower, outer rises toward cliffs
        float h = Mathf.Lerp(0.35f, 1.8f + hills * 1.6f, bank);
        h -= riverMask * 1.15f; // river dip
        h += (hint - 0.5f) * 2.2f;

        // Soft rise near map edges (natural enclosure before cliffs)
        float edge = Mathf.Max(Mathf.Abs(nx - 0.5f), Mathf.Abs(nz - 0.5f)) * 2f;
        if (edge > 0.72f)
            h += (edge - 0.72f) * 18f;

        // Keep southern spawn approach gentle
        if (nz < 0.22f && river > 4f && river < 14f)
            h = Mathf.Min(h, 2.4f);

        return Mathf.Clamp(h, -0.5f, maxHeight);
    }

    Color GroundColor(float nx, float nz, float h, float wx)
    {
        float river = Mathf.Abs(wx);
        if (river < 4.2f)
            return Color.Lerp(new Color(0.45f, 0.4f, 0.28f), new Color(0.35f, 0.5f, 0.35f), river / 4.2f); // wet sand/grass
        if (h > 6f)
            return new Color(0.55f, 0.58f, 0.52f); // rocky
        // sakura petal tint on banks
        float petal = Mathf.PerlinNoise(nx * 8f, nz * 8f);
        if (petal > 0.72f)
            return new Color(0.75f, 0.55f, 0.62f);
        return Color.Lerp(new Color(0.30f, 0.52f, 0.24f), new Color(0.40f, 0.60f, 0.32f), Mathf.PerlinNoise(nx * 5f, nz * 5f));
    }

    // ---------- River water ----------
    void BuildRiver()
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Plane);
        go.name = "River";
        go.transform.SetParent(root, false);
        go.transform.position = new Vector3(0f, 0.55f, 0f);
        go.transform.localScale = new Vector3(worldSize * 0.07f, 1f, worldSize * 0.095f);
        Object.Destroy(go.GetComponent<MeshCollider>()); // walkable banks; water is visual
        var scroller = go.AddComponent<RiverScroller>();
        var waterTex = MakeWaterTex();
        var mat = N64Materials.TextureMat(waterTex, new Color(0.45f, 0.65f, 0.95f, 0.85f), true);
        go.GetComponent<MeshRenderer>().sharedMaterial = mat;
        scroller.targetMaterial = mat;
        spawned.Add(go);

        // Shallow collision strips so you don't fall through river bed gaps — thin solid under water
        var bed = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bed.name = "RiverBed";
        bed.transform.SetParent(root, false);
        bed.transform.position = new Vector3(0f, 0.15f, 0f);
        bed.transform.localScale = new Vector3(7.5f, 0.4f, worldSize * 0.92f);
        Object.Destroy(bed.GetComponent<MeshRenderer>());
        spawned.Add(bed);
    }

    Texture2D MakeWaterTex()
    {
        int s = 64;
        var t = new Texture2D(s, s, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Bilinear;
        t.wrapMode = TextureWrapMode.Repeat;
        for (int y = 0; y < s; y++)
        for (int x = 0; x < s; x++)
        {
            float n = Mathf.PerlinNoise(x * 0.2f, y * 0.15f);
            Color c = Color.Lerp(new Color(0.25f, 0.45f, 0.8f, 0.9f), new Color(0.55f, 0.75f, 1f, 0.75f), n);
            t.SetPixel(x, y, c);
        }
        t.Apply();
        return t;
    }

    // ---------- Cliffs as natural bounds ----------
    void BuildCliffBounds()
    {
        float half = worldSize * 0.48f;
        PlaceCliffWall(new Vector3(0f, 5f, half), new Vector3(worldSize * 0.95f, 14f, 3.5f), "CliffNorth");
        PlaceCliffWall(new Vector3(0f, 4f, -half), new Vector3(worldSize * 0.95f, 10f, 3.5f), "CliffSouth");
        PlaceCliffWall(new Vector3(half, 5f, 0f), new Vector3(3.5f, 14f, worldSize * 0.95f), "CliffEast");
        PlaceCliffWall(new Vector3(-half, 5f, 0f), new Vector3(3.5f, 14f, worldSize * 0.95f), "CliffWest");

        // Extra rock knobs near corners for silhouette
        for (int i = 0; i < 6; i++)
        {
            float ang = i / 6f * Mathf.PI * 2f;
            float r = half * 0.88f;
            var rock = GameObject.CreatePrimitive(PrimitiveType.Cube);
            rock.name = "Rock_" + i;
            rock.transform.SetParent(root, false);
            rock.transform.position = new Vector3(Mathf.Cos(ang) * r, 2.5f + (i % 3), Mathf.Sin(ang) * r);
            rock.transform.localScale = new Vector3(4f + i % 3, 5f + i, 3.5f);
            rock.transform.rotation = Quaternion.Euler(0f, i * 40f, 8f);
            rock.GetComponent<MeshRenderer>().sharedMaterial = N64Materials.ColorMat(new Color(0.45f, 0.48f, 0.5f));
            spawned.Add(rock);
        }
    }

    void PlaceCliffWall(Vector3 pos, Vector3 scale, string name)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(root, false);
        go.transform.position = pos;
        go.transform.localScale = scale;
        var tex = N64Materials.SoftTintTex(new Color(0.4f, 0.42f, 0.45f), new Color(0.55f, 0.52f, 0.48f), 32);
        go.GetComponent<MeshRenderer>().sharedMaterial = N64Materials.TextureMat(tex, Color.white);
        spawned.Add(go);
    }

    // ---------- Landmark mountain (weenie) ----------
    void BuildDistantMountain()
    {
        var mt = new GameObject("SnowMountain");
        mt.transform.SetParent(root, false);
        mt.transform.position = new Vector3(-8f, 0f, worldSize * 0.55f + 8f);
        spawned.Add(mt);

        // Stacked cones / stretched spheres for soft N64 mountain
        AddPeak(mt.transform, new Vector3(0f, 10f, 0f), new Vector3(28f, 22f, 22f), new Color(0.5f, 0.55f, 0.6f));
        AddPeak(mt.transform, new Vector3(-10f, 7f, 4f), new Vector3(16f, 14f, 14f), new Color(0.48f, 0.52f, 0.58f));
        AddPeak(mt.transform, new Vector3(8f, 6f, -2f), new Vector3(14f, 12f, 12f), new Color(0.52f, 0.55f, 0.6f));
        // Snow caps
        AddPeak(mt.transform, new Vector3(0f, 20f, 0f), new Vector3(12f, 8f, 10f), new Color(0.92f, 0.94f, 0.98f));
        AddPeak(mt.transform, new Vector3(-8f, 14f, 3f), new Vector3(7f, 5f, 6f), new Color(0.9f, 0.93f, 0.97f));
    }

    void AddPeak(Transform parent, Vector3 localPos, Vector3 scale, Color col)
    {
        var p = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        p.name = "Peak";
        p.transform.SetParent(parent, false);
        p.transform.localPosition = localPos;
        p.transform.localScale = scale;
        Object.Destroy(p.GetComponent<Collider>());
        p.GetComponent<MeshRenderer>().sharedMaterial = N64Materials.ColorMat(col);
    }

    // ---------- Soft sky gradient dome ----------
    void BuildSkyDome()
    {
        var sky = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sky.name = "SkyDome";
        sky.transform.SetParent(root, false);
        sky.transform.localScale = Vector3.one * (worldSize * 1.6f);
        sky.transform.position = new Vector3(0f, 8f, 0f);
        Object.Destroy(sky.GetComponent<Collider>());
        var r = sky.GetComponent<MeshRenderer>();
        r.sharedMaterial = N64Materials.TextureMat(MakeSkyTex(), Color.white);
        // Flip normals trick: scale X negative so we see inside
        sky.transform.localScale = new Vector3(-worldSize * 1.6f, worldSize * 1.4f, worldSize * 1.6f);
        spawned.Add(sky);
    }

    Texture2D MakeSkyTex()
    {
        int w = 8, h = 32;
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Bilinear;
        t.wrapMode = TextureWrapMode.Clamp;
        Color top = new Color(0.35f, 0.5f, 0.85f);
        Color horizon = new Color(0.75f, 0.8f, 0.95f);
        Color fogBand = new Color(0.62f, 0.72f, 0.88f);
        for (int y = 0; y < h; y++)
        {
            float v = y / (float)(h - 1);
            Color c = v < 0.35f ? Color.Lerp(fogBand, horizon, v / 0.35f) : Color.Lerp(horizon, top, (v - 0.35f) / 0.65f);
            for (int x = 0; x < w; x++)
                t.SetPixel(x, y, c);
        }
        t.Apply();
        return t;
    }

    // ---------- Sakura billboard trees ----------
    void PlaceSakuraTrees()
    {
        var parent = new GameObject("SakuraTrees").transform;
        parent.SetParent(root, false);
        spawned.Add(parent.gameObject);

        var canopyTex = N64Materials.SoftCircle(new Color(1f, 0.72f, 0.85f, 1f), 64);
        var canopyMat = N64Materials.TextureMat(canopyTex, Color.white, true);
        var trunkMat = N64Materials.ColorMat(new Color(0.35f, 0.22f, 0.15f));

        // Place along banks — readable clusters like OoT Hyrule Field trees
        Vector3[] sites =
        {
            new Vector3(-11f, 0f, -18f), new Vector3(-13f, 0f, -10f), new Vector3(-12f, 0f, 0f),
            new Vector3(-14f, 0f, 12f), new Vector3(-11f, 0f, 22f),
            new Vector3(11f, 0f, -16f), new Vector3(13f, 0f, -6f), new Vector3(12f, 0f, 6f),
            new Vector3(14f, 0f, 16f), new Vector3(11f, 0f, 26f),
            new Vector3(-18f, 0f, -22f), new Vector3(18f, 0f, -24f),
            new Vector3(-20f, 0f, 8f), new Vector3(20f, 0f, 10f),
            new Vector3(-8f, 0f, 30f), new Vector3(8f, 0f, 32f),
        };

        for (int i = 0; i < sites.Length; i++)
        {
            Vector3 p = sites[i];
            p.y = SampleHeight((p.x / worldSize) + 0.5f, (p.z / worldSize) + 0.5f, p.x, p.z);
            float scale = 0.85f + (i % 4) * 0.12f;
            SpawnTree(parent, p, scale, trunkMat, canopyMat);
        }
    }

    void SpawnTree(Transform parent, Vector3 pos, float scale, Material trunkMat, Material canopyMat)
    {
        var tree = new GameObject("Sakura");
        tree.transform.SetParent(parent, false);
        tree.transform.position = pos;

        var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.name = "Trunk";
        trunk.transform.SetParent(tree.transform, false);
        trunk.transform.localPosition = new Vector3(0f, 1.1f * scale, 0f);
        trunk.transform.localScale = new Vector3(0.35f * scale, 1.1f * scale, 0.35f * scale);
        trunk.GetComponent<MeshRenderer>().sharedMaterial = trunkMat;

        // Billboard / blob canopies (2–3 quads)
        for (int i = 0; i < 3; i++)
        {
            var quad = GameObject.CreatePrimitive(PrimitiveType.Quad);
            quad.name = "Blossom";
            quad.transform.SetParent(tree.transform, false);
            float ang = i * 60f;
            quad.transform.localPosition = new Vector3(0f, 2.3f * scale + i * 0.15f, 0f);
            quad.transform.localRotation = Quaternion.Euler(0f, ang, 0f);
            float s = (2.4f - i * 0.25f) * scale;
            quad.transform.localScale = new Vector3(s, s, s);
            Object.Destroy(quad.GetComponent<MeshCollider>());
            quad.GetComponent<MeshRenderer>().sharedMaterial = canopyMat;
            // duplicate backface
            var quad2 = Instantiate(quad, tree.transform);
            quad2.transform.localRotation = Quaternion.Euler(0f, ang + 180f, 0f);
            Object.Destroy(quad2.GetComponent<MeshCollider>());
        }

    }

    // ---------- Props: crates, grass cards, bench ----------
    void PlaceProps()
    {
        var parent = new GameObject("Props").transform;
        parent.SetParent(root, false);
        spawned.Add(parent.gameObject);

        var crateMat = N64Materials.ColorMat(new Color(0.55f, 0.38f, 0.22f));
        var grassCardMat = N64Materials.TextureMat(
            N64Materials.SoftCircle(new Color(0.35f, 0.7f, 0.3f, 1f), 32),
            Color.white, true);
        var benchMat = N64Materials.ColorMat(new Color(0.4f, 0.28f, 0.18f));

        PlaceCrate(parent, new Vector3(-9.5f, 0f, -20f), crateMat);
        PlaceCrate(parent, new Vector3(-8.6f, 0f, -19.2f), crateMat);
        PlaceCrate(parent, new Vector3(10f, 0f, -12f), crateMat);

        PlaceBench(parent, new Vector3(9f, 0f, -22f), benchMat);

        // Grass cards along banks
        for (int i = 0; i < 24; i++)
        {
            float side = (i % 2 == 0) ? -1f : 1f;
            float z = -30f + i * 2.6f;
            float x = side * (6.5f + (i % 5) * 0.8f);
            var g = GameObject.CreatePrimitive(PrimitiveType.Quad);
            g.name = "GrassCard";
            g.transform.SetParent(parent, false);
            float y = SampleHeight((x / worldSize) + 0.5f, (z / worldSize) + 0.5f, x, z) + 0.45f;
            g.transform.position = new Vector3(x, y, z);
            g.transform.localScale = new Vector3(1.2f, 0.9f, 1f);
            Object.Destroy(g.GetComponent<MeshCollider>());
            g.GetComponent<MeshRenderer>().sharedMaterial = grassCardMat;
            g.AddComponent<BillboardY>();
        }
    }

    void PlaceCrate(Transform parent, Vector3 approx, Material mat)
    {
        var c = GameObject.CreatePrimitive(PrimitiveType.Cube);
        c.name = "Crate";
        c.transform.SetParent(parent, false);
        float y = SampleHeight((approx.x / worldSize) + 0.5f, (approx.z / worldSize) + 0.5f, approx.x, approx.z);
        c.transform.position = new Vector3(approx.x, y + 0.4f, approx.z);
        c.transform.localScale = new Vector3(0.8f, 0.8f, 0.8f);
        c.transform.rotation = Quaternion.Euler(0f, 18f, 0f);
        c.GetComponent<MeshRenderer>().sharedMaterial = mat;
    }

    void PlaceBench(Transform parent, Vector3 approx, Material mat)
    {
        var b = GameObject.CreatePrimitive(PrimitiveType.Cube);
        b.name = "Bench";
        b.transform.SetParent(parent, false);
        float y = SampleHeight((approx.x / worldSize) + 0.5f, (approx.z / worldSize) + 0.5f, approx.x, approx.z);
        b.transform.position = new Vector3(approx.x, y + 0.25f, approx.z);
        b.transform.localScale = new Vector3(1.8f, 0.35f, 0.55f);
        b.GetComponent<MeshRenderer>().sharedMaterial = mat;
    }

    // ---------- Rupee-like tokens ----------
    void PlaceCollectibles()
    {
        var parent = new GameObject("Tokens").transform;
        parent.SetParent(root, false);
        spawned.Add(parent.gameObject);

        Vector3[] spots =
        {
            new Vector3(-7f, 0f, -14f), new Vector3(7.5f, 0f, -8f),
            new Vector3(-8f, 0f, 4f), new Vector3(8f, 0f, 14f),
            new Vector3(0.5f, 0f, 20f), new Vector3(-10f, 0f, 28f),
        };

        var mat = N64Materials.ColorMat(new Color(0.35f, 0.95f, 0.45f)); // green rupee-ish
        for (int i = 0; i < spots.Length; i++)
        {
            Vector3 s = spots[i];
            float y = SampleHeight((s.x / worldSize) + 0.5f, (s.z / worldSize) + 0.5f, s.x, s.z);
            var token = GameObject.CreatePrimitive(PrimitiveType.Cube);
            token.name = "Token";
            token.transform.SetParent(parent, false);
            token.transform.position = new Vector3(s.x, y + 0.9f, s.z);
            token.transform.localScale = new Vector3(0.35f, 0.55f, 0.12f);
            token.transform.rotation = Quaternion.Euler(0f, 45f, 0f);
            token.GetComponent<MeshRenderer>().sharedMaterial = mat;
            var col = token.GetComponent<BoxCollider>();
            col.isTrigger = true;
            token.AddComponent<SparkleToken>();
        }
    }

    void SetupLighting()
    {
        // Soft directional — unlit mats ignore most of this, but ambient/fog matter
        RenderSettings.ambientLight = new Color(0.55f, 0.58f, 0.65f);
        var lightGo = new GameObject("Sun");
        lightGo.transform.SetParent(root, false);
        lightGo.transform.rotation = Quaternion.Euler(42f, 30f, 0f);
        var light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.color = new Color(1f, 0.95f, 0.85f);
        light.intensity = 0.85f;
        light.shadows = LightShadows.None;
        spawned.Add(lightGo);
    }

    Vector3 SampleSpawnOnBank()
    {
        float x = -8.5f;
        float z = -26f;
        float y = SampleHeight((x / worldSize) + 0.5f, (z / worldSize) + 0.5f, x, z) + 1.2f;
        return new Vector3(x, y, z);
    }
}

/// <summary>Scroll UVs on river material for simple flowing water.</summary>
public class RiverScroller : MonoBehaviour
{
    public Material targetMaterial;
    public Vector2 speed = new Vector2(0f, 0.08f);
    Vector2 offset;

    void Update()
    {
        if (targetMaterial == null) return;
        offset += speed * Time.deltaTime;
        if (targetMaterial.HasProperty("_BaseMap"))
            targetMaterial.SetTextureOffset("_BaseMap", offset);
        if (targetMaterial.HasProperty("_MainTex"))
            targetMaterial.SetTextureOffset("_MainTex", offset);
    }
}

/// <summary>Y-axis billboard toward main camera.</summary>
public class BillboardY : MonoBehaviour
{
    void LateUpdate()
    {
        var cam = Camera.main;
        if (cam == null) return;
        Vector3 f = cam.transform.position - transform.position;
        f.y = 0f;
        if (f.sqrMagnitude < 0.001f) return;
        // Only rotate root if this is a tree root; for quads face camera
        if (GetComponent<MeshFilter>() != null)
            transform.rotation = Quaternion.LookRotation(-f.normalized, Vector3.up);
    }
}

/// <summary>Simple spinning collectible token (rupee-like).</summary>
public class SparkleToken : MonoBehaviour
{
    public float spin = 90f;
    public float bob = 0.25f;
    Vector3 basePos;
    bool taken;

    void Start() => basePos = transform.position;

    void Update()
    {
        if (taken) return;
        transform.Rotate(0f, spin * Time.deltaTime, 0f, Space.World);
        transform.position = basePos + Vector3.up * Mathf.Sin(Time.time * 3f) * bob;
    }

    void OnTriggerEnter(Collider other)
    {
        if (taken) return;
        if (other.GetComponent<SimplePlayerController>() == null &&
            other.GetComponentInParent<SimplePlayerController>() == null)
            return;
        taken = true;
        Debug.Log("[Forge64] Token collected!");
        Destroy(gameObject);
    }
}
