using UnityEngine;

/// <summary>
/// N64-era adventure movement: tank-style turn + move (OoT/MM feel).
/// WASD: W/S walk forward/back relative to facing; A/D turn in place.
/// Optional analog stick-style: hold W and turn with A/D while moving.
/// Modest adventure pacing — not arena-shooter freelook strafing.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class SimplePlayerController : MonoBehaviour
{
    [Header("Adventure pacing (OoT-ish)")]
    public float walkSpeed = 3.6f;
    public float runSpeed = 5.4f;
    public float turnSpeed = 110f;
    public float gravity = -22f;
    public float jumpHeight = 1.1f;
    public bool allowJump = true;

    [Header("Camera")]
    public AdventureCamera adventureCamera;

    CharacterController controller;
    float verticalVelocity;
    bool inputEnabled = true;

    public bool InputEnabled
    {
        get => inputEnabled;
        set => inputEnabled = value;
    }

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (adventureCamera == null)
            adventureCamera = FindObjectOfType<AdventureCamera>();
    }

    void Update()
    {
        if (!inputEnabled)
        {
            ApplyGravityOnly();
            return;
        }

        // Tank turn
        float turn = Input.GetAxisRaw("Horizontal");
        if (Mathf.Abs(turn) > 0.01f)
            transform.Rotate(0f, turn * turnSpeed * Time.deltaTime, 0f);

        // Forward/back relative to facing (classic adventure)
        float fwd = Input.GetAxisRaw("Vertical");
        bool run = Input.GetKey(KeyCode.LeftShift) || Input.GetButton("Fire3");
        float speed = run ? runSpeed : walkSpeed;

        Vector3 move = transform.forward * fwd * speed;

        // Soft Z-target / L-center recentering (hold Q or Left Ctrl)
        if (adventureCamera != null && (Input.GetKey(KeyCode.Q) || Input.GetKey(KeyCode.LeftControl)))
            adventureCamera.RequestRecenter();

        if (controller.isGrounded)
        {
            if (verticalVelocity < 0f)
                verticalVelocity = -2f;
            if (allowJump && (Input.GetButtonDown("Jump") || Input.GetKeyDown(KeyCode.Space)))
                verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        verticalVelocity += gravity * Time.deltaTime;
        move.y = verticalVelocity;
        controller.Move(move * Time.deltaTime);
    }

    void ApplyGravityOnly()
    {
        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;
        verticalVelocity += gravity * Time.deltaTime;
        controller.Move(new Vector3(0f, verticalVelocity, 0f) * Time.deltaTime);
    }

    public void Teleport(Vector3 position, float yawDeg = 0f)
    {
        controller.enabled = false;
        transform.position = position;
        transform.rotation = Quaternion.Euler(0f, yawDeg, 0f);
        controller.enabled = true;
        verticalVelocity = 0f;
        if (adventureCamera != null)
            adventureCamera.SnapBehind();
    }

    public float GetYaw() => transform.eulerAngles.y;
}
