using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

/// <summary>
/// Runtime bootstrap: builds HUD (prompt, Generate Concept, Build Map),
/// wires ConceptService / ValleyMapBuilder / player / N64 look.
/// Auto-builds valley on Play so a non-dev can walk immediately; UI still exposed.
/// Uses RuntimeInitializeOnLoad so an empty scene still works.
/// </summary>
public class Forge64Bootstrap : MonoBehaviour
{
    public static Forge64Bootstrap Instance { get; private set; }

    ConceptService concepts;
    ValleyMapBuilder mapBuilder;
    ProjectSaveLoad saveLoad;
    SimplePlayerController player;
    AdventureCamera advCam;
    N64Look n64;

    InputField promptField;
    Text statusText;
    RawImage conceptPreview;
    bool mapBuilt;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void AutoBoot()
    {
        if (FindObjectOfType<Forge64Bootstrap>() != null)
            return;
        var go = new GameObject("Forge64Bootstrap");
        go.AddComponent<Forge64Bootstrap>();
    }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        concepts = gameObject.AddComponent<ConceptService>();
        mapBuilder = gameObject.AddComponent<ValleyMapBuilder>();
        saveLoad = gameObject.AddComponent<ProjectSaveLoad>();

        EnsureEventSystem();
        BuildHud();
        EnsureCameraAndLight();

        concepts.LoadDefaultConcept();
        if (conceptPreview != null && concepts.CurrentConcept != null)
            conceptPreview.texture = concepts.CurrentConcept;

        if (promptField != null)
            promptField.text = concepts.LastPrompt;

        // Auto-build so Play = walkable valley; buttons still work for rebuild.
        BuildMap();
        TryRestoreSave();
        SetStatus("Sakura Valley ready — WASD tank move, Shift run, Q recenter cam, Esc free cursor.");
    }

    void EnsureEventSystem()
    {
        if (FindObjectOfType<EventSystem>() != null) return;
        var es = new GameObject("EventSystem");
        es.AddComponent<EventSystem>();
        es.AddComponent<StandaloneInputModule>();
    }

    void EnsureCameraAndLight()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            var camGo = new GameObject("Main Camera");
            cam = camGo.AddComponent<Camera>();
            cam.tag = "MainCamera";
            camGo.AddComponent<AudioListener>();
        }
        advCam = cam.GetComponent<AdventureCamera>();
        if (advCam == null)
            advCam = cam.gameObject.AddComponent<AdventureCamera>();

        n64 = cam.GetComponent<N64Look>();
        if (n64 == null)
            n64 = cam.gameObject.AddComponent<N64Look>();
        n64.Refresh();

        if (FindObjectOfType<Light>() == null)
        {
            var sun = new GameObject("BootstrapSun");
            sun.transform.rotation = Quaternion.Euler(40f, 25f, 0f);
            var l = sun.AddComponent<Light>();
            l.type = LightType.Directional;
            l.intensity = 0.8f;
            l.shadows = LightShadows.None;
        }
    }

    void BuildHud()
    {
        var canvasGo = new GameObject("Forge64HUD");
        var canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;
        var scaler = canvasGo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 720);
        canvasGo.AddComponent<GraphicRaycaster>();

        // Panel
        var panel = CreateUIObject("Panel", canvasGo.transform);
        var panelImg = panel.AddComponent<Image>();
        panelImg.color = new Color(0.05f, 0.07f, 0.12f, 0.72f);
        var prt = panel.GetComponent<RectTransform>();
        AnchorTopLeft(prt, new Vector2(12, -12), new Vector2(420, 210));

        var title = CreateText(panel.transform, "Title", "Forge64 — Valley Walk", 18, FontStyle.Bold);
        AnchorTopLeft(title.rectTransform, new Vector2(10, -8), new Vector2(400, 28));

        var help = CreateText(panel.transform, "Help",
            "Inspired by N64-era Zelda adventure games.\n1) Edit prompt  2) Generate Concept (stub)  3) Build Map  4) Walk",
            12, FontStyle.Normal);
        AnchorTopLeft(help.rectTransform, new Vector2(10, -36), new Vector2(400, 40));

        // Prompt
        var promptGo = CreateUIObject("Prompt", panel.transform);
        var promptBg = promptGo.AddComponent<Image>();
        promptBg.color = new Color(0.15f, 0.18f, 0.25f, 0.95f);
        AnchorTopLeft(promptGo.GetComponent<RectTransform>(), new Vector2(10, -82), new Vector2(400, 32));
        promptField = promptGo.AddComponent<InputField>();
        var promptText = CreateText(promptGo.transform, "Text", "", 14, FontStyle.Normal);
        promptText.supportRichText = false;
        promptText.color = Color.white;
        Stretch(promptText.rectTransform, 6, 4);
        var placeholder = CreateText(promptGo.transform, "Placeholder", "sakura river valley, snow mountain…", 14, FontStyle.Italic);
        placeholder.color = new Color(1f, 1f, 1f, 0.35f);
        Stretch(placeholder.rectTransform, 6, 4);
        promptField.textComponent = promptText;
        promptField.placeholder = placeholder;

        // Buttons
        var btnGen = CreateButton(panel.transform, "BtnGenerate", "Generate Concept", new Vector2(10, -122), new Vector2(190, 32));
        btnGen.onClick.AddListener(OnGenerateConcept);
        var btnBuild = CreateButton(panel.transform, "BtnBuild", "Build Map", new Vector2(210, -122), new Vector2(190, 32));
        btnBuild.onClick.AddListener(BuildMap);
        var btnSave = CreateButton(panel.transform, "BtnSave", "Save", new Vector2(10, -160), new Vector2(90, 28));
        btnSave.onClick.AddListener(OnSave);
        var btnLoad = CreateButton(panel.transform, "BtnLoad", "Load", new Vector2(110, -160), new Vector2(90, 28));
        btnLoad.onClick.AddListener(OnLoad);

        statusText = CreateText(panel.transform, "Status", "", 11, FontStyle.Normal);
        AnchorTopLeft(statusText.rectTransform, new Vector2(210, -158), new Vector2(200, 36));

        // Concept preview (small)
        var previewGo = CreateUIObject("ConceptPreview", canvasGo.transform);
        conceptPreview = previewGo.AddComponent<RawImage>();
        conceptPreview.color = Color.white;
        var pv = previewGo.GetComponent<RectTransform>();
        pv.anchorMin = new Vector2(1f, 1f);
        pv.anchorMax = new Vector2(1f, 1f);
        pv.pivot = new Vector2(1f, 1f);
        pv.anchoredPosition = new Vector2(-12, -12);
        pv.sizeDelta = new Vector2(160, 100);

        var controls = CreateText(canvasGo.transform, "Controls",
            "W/S move  A/D turn  Shift run  Space jump  Q camera center  RMB/Esc cursor",
            13, FontStyle.Normal);
        var crt = controls.rectTransform;
        crt.anchorMin = new Vector2(0.5f, 0f);
        crt.anchorMax = new Vector2(0.5f, 0f);
        crt.pivot = new Vector2(0.5f, 0f);
        crt.anchoredPosition = new Vector2(0, 10);
        crt.sizeDelta = new Vector2(900, 24);
        controls.alignment = TextAnchor.MiddleCenter;
        controls.color = new Color(1f, 1f, 1f, 0.75f);
    }

    void OnGenerateConcept()
    {
        string prompt = promptField != null ? promptField.text : "";
        var tex = concepts.GenerateConceptStub(prompt);
        if (conceptPreview != null)
            conceptPreview.texture = tex;
        SetStatus("Concept stub: default art kept. Flux not wired (offline).");
    }

    public void BuildMap()
    {
        if (concepts.CurrentConcept == null)
            concepts.LoadDefaultConcept();
        if (conceptPreview != null)
            conceptPreview.texture = concepts.CurrentConcept;

        mapBuilder.Build(concepts.CurrentConcept);
        SpawnOrMovePlayer(mapBuilder.RecommendedSpawn);
        mapBuilt = true;
        if (n64 != null) n64.Refresh();
        SetStatus("Map built — explore the sakura river valley.");
    }

    void SpawnOrMovePlayer(Vector3 pos)
    {
        if (player == null)
        {
            var go = new GameObject("Player");
            go.tag = "Player";
            var cc = go.AddComponent<CharacterController>();
            cc.height = 1.6f;
            cc.radius = 0.35f;
            cc.center = new Vector3(0f, 0.8f, 0f);
            cc.stepOffset = 0.35f;
            cc.skinWidth = 0.08f;

            // Visible body (simple hero capsule — readable third-person)
            var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            body.name = "Body";
            body.transform.SetParent(go.transform, false);
            body.transform.localPosition = new Vector3(0f, 0.9f, 0f);
            body.transform.localScale = new Vector3(0.7f, 0.85f, 0.7f);
            Object.Destroy(body.GetComponent<Collider>());
            body.GetComponent<MeshRenderer>().sharedMaterial =
                N64Materials.ColorMat(new Color(0.25f, 0.45f, 0.85f)); // tunic-ish blue (original)

            var hat = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            hat.name = "Head";
            hat.transform.SetParent(go.transform, false);
            hat.transform.localPosition = new Vector3(0f, 1.55f, 0.05f);
            hat.transform.localScale = new Vector3(0.45f, 0.45f, 0.45f);
            Object.Destroy(hat.GetComponent<Collider>());
            hat.GetComponent<MeshRenderer>().sharedMaterial =
                N64Materials.ColorMat(new Color(0.2f, 0.55f, 0.25f));

            player = go.AddComponent<SimplePlayerController>();
            player.adventureCamera = advCam;
        }

        player.Teleport(pos, 0f);
        if (advCam != null)
        {
            advCam.SetTarget(player.transform);
            advCam.SnapBehind();
        }
    }

    void OnSave()
    {
        if (player == null) return;
        var p = player.transform.position;
        saveLoad.Save(new Forge64SaveData
        {
            prompt = promptField != null ? promptField.text : concepts.LastPrompt,
            mapBuilt = mapBuilt,
            playerX = p.x, playerY = p.y, playerZ = p.z,
            lookYaw = player.GetYaw(),
            lookPitch = 0f
        });
        SetStatus("Saved to persistentDataPath.");
    }

    void OnLoad()
    {
        if (!saveLoad.TryLoad(out var data))
        {
            SetStatus("No save found.");
            return;
        }
        if (promptField != null)
            promptField.text = data.prompt;
        concepts.GenerateConceptStub(data.prompt);
        if (!mapBuilt)
            BuildMap();
        if (player != null)
            player.Teleport(new Vector3(data.playerX, data.playerY, data.playerZ), data.lookYaw);
        SetStatus("Save loaded.");
    }

    void TryRestoreSave()
    {
        // Soft restore position only if save exists — don't surprise non-devs
        if (!saveLoad.TryLoad(out var data)) return;
        if (player != null && data.mapBuilt)
            player.Teleport(new Vector3(data.playerX, data.playerY, data.playerZ), data.lookYaw);
    }

    void SetStatus(string msg)
    {
        if (statusText != null) statusText.text = msg;
        Debug.Log("[Forge64] " + msg);
    }

    // ---- UI helpers (uGUI, no TMP required) ----
    static GameObject CreateUIObject(string name, Transform parent)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.AddComponent<RectTransform>();
        return go;
    }

    static Text CreateText(Transform parent, string name, string msg, int size, FontStyle style)
    {
        var go = CreateUIObject(name, parent);
        var t = go.AddComponent<Text>();
        t.text = msg;
        t.fontSize = size;
        t.fontStyle = style;
        t.color = Color.white;
        t.alignment = TextAnchor.UpperLeft;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf")
              ?? Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        return t;
    }

    static Button CreateButton(Transform parent, string name, string label, Vector2 anchoredPos, Vector2 size)
    {
        var go = CreateUIObject(name, parent);
        var img = go.AddComponent<Image>();
        img.color = new Color(0.2f, 0.45f, 0.35f, 0.95f);
        AnchorTopLeft(go.GetComponent<RectTransform>(), anchoredPos, size);
        var btn = go.AddComponent<Button>();
        var colors = btn.colors;
        colors.highlightedColor = new Color(0.3f, 0.6f, 0.45f);
        colors.pressedColor = new Color(0.15f, 0.35f, 0.28f);
        btn.colors = colors;
        var text = CreateText(go.transform, "Label", label, 13, FontStyle.Bold);
        text.alignment = TextAnchor.MiddleCenter;
        Stretch(text.rectTransform, 2, 2);
        return btn;
    }

    static void AnchorTopLeft(RectTransform rt, Vector2 anchoredPos, Vector2 size)
    {
        rt.anchorMin = new Vector2(0f, 1f);
        rt.anchorMax = new Vector2(0f, 1f);
        rt.pivot = new Vector2(0f, 1f);
        rt.anchoredPosition = anchoredPos;
        rt.sizeDelta = size;
    }

    static void Stretch(RectTransform rt, float padX, float padY)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = new Vector2(padX, padY);
        rt.offsetMax = new Vector2(-padX, -padY);
    }
}
