using System;
using System.IO;
using UnityEngine;

/// <summary>
/// Minimal save/load to Application.persistentDataPath (no network).
/// </summary>
[Serializable]
public class Forge64SaveData
{
    public string prompt = "";
    public bool mapBuilt;
    public float playerX, playerY, playerZ;
    public float lookYaw, lookPitch;
}

public class ProjectSaveLoad : MonoBehaviour
{
    const string FileName = "forge64_save.json";

    public static string SavePath => Path.Combine(Application.persistentDataPath, FileName);

    public void Save(Forge64SaveData data)
    {
        try
        {
            string json = JsonUtility.ToJson(data, true);
            File.WriteAllText(SavePath, json);
            Debug.Log($"[ProjectSaveLoad] Saved → {SavePath}");
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[ProjectSaveLoad] Save failed: {e.Message}");
        }
    }

    public bool TryLoad(out Forge64SaveData data)
    {
        data = new Forge64SaveData();
        try
        {
            if (!File.Exists(SavePath))
                return false;
            string json = File.ReadAllText(SavePath);
            data = JsonUtility.FromJson<Forge64SaveData>(json) ?? new Forge64SaveData();
            Debug.Log($"[ProjectSaveLoad] Loaded ← {SavePath}");
            return true;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[ProjectSaveLoad] Load failed: {e.Message}");
            return false;
        }
    }
}
