using UnityEngine;

/// <summary>
/// Soft third-person follow behind the player (OoT/MM field camera vibe).
/// Optional L-centering via RequestRecenter(). Keeps hero readable.
/// </summary>
public class AdventureCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 pivotOffset = new Vector3(0f, 1.35f, 0f);
    public float distance = 5.5f;
    public float height = 2.2f;
    public float followLag = 6f;
    public float yawLag = 5f;
    public float pitchAngle = 18f;
    public float recenterSpeed = 8f;

    float orbitYaw;
    bool recenter;

    public void SetTarget(Transform t)
    {
        target = t;
        SnapBehind();
    }

    public void RequestRecenter() => recenter = true;

    public void SnapBehind()
    {
        if (target == null) return;
        orbitYaw = target.eulerAngles.y;
        recenter = false;
        ApplyPose(1f);
    }

    void LateUpdate()
    {
        if (target == null) return;

        float desiredYaw = target.eulerAngles.y;
        if (recenter)
        {
            orbitYaw = Mathf.LerpAngle(orbitYaw, desiredYaw, recenterSpeed * Time.deltaTime);
            if (Mathf.Abs(Mathf.DeltaAngle(orbitYaw, desiredYaw)) < 1.5f)
            {
                orbitYaw = desiredYaw;
                recenter = false;
            }
        }
        else
        {
            // Soft drift toward behind-player without hard lock (field camera feel)
            orbitYaw = Mathf.LerpAngle(orbitYaw, desiredYaw, yawLag * Time.deltaTime * 0.35f);
        }

        ApplyPose(followLag * Time.deltaTime);
    }

    void ApplyPose(float t)
    {
        Quaternion rot = Quaternion.Euler(pitchAngle, orbitYaw, 0f);
        Vector3 pivot = target.position + pivotOffset;
        Vector3 desired = pivot - rot * Vector3.forward * distance + Vector3.up * (height * 0.15f);
        transform.position = Vector3.Lerp(transform.position, desired, Mathf.Clamp01(t));
        Vector3 lookAt = pivot + Vector3.up * 0.2f;
        Quaternion look = Quaternion.LookRotation((lookAt - transform.position).normalized, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, look, Mathf.Clamp01(t * 1.2f));
    }
}
